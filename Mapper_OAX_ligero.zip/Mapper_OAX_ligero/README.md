# Mapper OAX ligero

Esta carpeta contiene un notebook más ligero y los datos ya construidos.

- `Mapper_OAX_ligero.ipynb`: notebook principal.
- `Datos/`: archivos CSV usados en los ejemplos.
- `Dibujos/`: aquí se guardan figuras PNG.
- `Salidas_mapper/`: aquí se guardan archivos HTML de Mapper.

Los datos sintéticos ya están generados para que el notebook se concentre en:
1. cargar los datos,
2. visualizarlos,
3. elegir un filtro,
4. construir Mapper.
